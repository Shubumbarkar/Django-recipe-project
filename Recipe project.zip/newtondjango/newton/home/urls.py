from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.homie, name='homie'),
    path('contact', views.contact, name='hello'),
    path('about', views.about, name='hello'),
]

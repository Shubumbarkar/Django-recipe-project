from django.shortcuts import render
from django.http import HttpResponse


def homie(request):
    countries = [{'city': 'delhi', 'food': 'chole'},
                 {'city': 'new york', 'food': 'pizza'},
                 {'city': 'moscow', 'food': 'burgur'},
                 {'city': 'otawa', 'food': 'fish'}, ]
    context={'countries':countries}
    for country,food in countries:
        print(country,food)
    return render(request, 'index.html',context)


def contact(request):
    return render(request,'contact.html')

def about(request):
    return render(request,'about.html')

from django.shortcuts import render,redirect
from .models import *


# Create your views here.
def receipe(request):
    if request.method == 'POST':

        data = request.POST
        receipe_name = data.get('receipe_name')
        receipe_desc = data.get('receipe_desc')
        receipe_img=request.FILES.get('receipe_img')
        print(receipe_name,receipe_desc,receipe_img)
        Receipe.objects.create(
            receipe_name=receipe_name,
            receipe_desc=receipe_desc,
            receipe_img=receipe_img,


        )
    queryset=Receipe.objects.all()
    context={
        'receipes':queryset
    }

    return render(request, 'receipe.html',context)


def delete_receipe(request,id):
    return redirect('/')
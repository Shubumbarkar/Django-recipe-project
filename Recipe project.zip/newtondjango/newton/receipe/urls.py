from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [

    path('receipe', views.receipe, name='receipe'),
    path('delete_receipe/<id>/', views.delete_receipe, name='delete_receipe'),
]
